
package arrayaufgabe2;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Random;


public class ArrayAufgabe2 {

    public static void main(String[] args) throws IOException {
    BufferedWriter writer = new BufferedWriter(new FileWriter(file));
    writer.write();
        int[][]Palme = new int [20][20];
        
        
     for(int i=0; i<Palme.length; i++)
     {
         for(int j=0; j<Palme.length; j++)
     {
        int x = randomInt(100);
        if(x<70)
        {
           Palme[i][j]=0;
        }
        else 
        {
          Palme[i][j]=1;        
        }
        System.out.print(Palme[i][j]+"  ");
     } System.out.println();
    }
     writer.close();
    }
 
public static int randomInt(int max) {
         Random rand = new Random();
         int randomInteger = rand.nextInt(max);
      
         return randomInteger;
     }
}